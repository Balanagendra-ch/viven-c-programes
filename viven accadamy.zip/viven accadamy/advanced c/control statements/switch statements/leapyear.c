#include <stdio.h>
int main()
{
int months
scanf("%d",&29)
if (month=29 days)
printf("leap year");
else 
printf("invalid input");
}
}
