#include <stdio.h>
int main()
{
int months;
scanf("%d",&months);
switch(months)
{
case 2:printf("29daysleapyear")
break;
}
}
