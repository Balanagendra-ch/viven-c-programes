#include <stdio.h>
int main()
{
int i=11;
switch(i%10)
{
case 1:printf("1");
case 2:printf("2");
default :print("NONE")
}
}

