#include <stdio.h>
int main()
{
int i;
for(i=10;i>0;i=i-2)
{
printf("%d",i);
}
}
